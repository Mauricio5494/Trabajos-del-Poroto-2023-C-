﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora.Clases
{
    internal class ClassResta
    {
        public double Restar(double n1, double n2)
        {
            double R;
            R = n1 - n2;
            return R;
        }
    }
}
