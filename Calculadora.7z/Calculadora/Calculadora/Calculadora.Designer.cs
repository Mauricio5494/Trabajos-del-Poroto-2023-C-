﻿namespace Calculadora
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            siete = new Button();
            uno = new Button();
            cuatro = new Button();
            dos = new Button();
            ocho = new Button();
            tres = new Button();
            seis = new Button();
            borrarButton = new Button();
            clearButton = new Button();
            igual = new Button();
            puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas = new Button();
            cero = new Button();
            multiplicarButton = new Button();
            dividirButton = new Button();
            sumarButton = new Button();
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos = new TextBox();
            nueve = new Button();
            cinco = new Button();
            restarButton = new Button();
            SuspendLayout();
            // 
            // siete
            // 
            resources.ApplyResources(siete, "siete");
            siete.BackColor = SystemColors.ButtonFace;
            siete.Name = "siete";
            siete.UseVisualStyleBackColor = false;
            siete.Click += siete_Click;
            // 
            // uno
            // 
            resources.ApplyResources(uno, "uno");
            uno.BackColor = SystemColors.ButtonFace;
            uno.Name = "uno";
            uno.UseVisualStyleBackColor = false;
            uno.Click += uno_Click;
            // 
            // cuatro
            // 
            resources.ApplyResources(cuatro, "cuatro");
            cuatro.BackColor = SystemColors.ButtonFace;
            cuatro.Name = "cuatro";
            cuatro.UseVisualStyleBackColor = false;
            cuatro.Click += cuatro_Click;
            // 
            // dos
            // 
            resources.ApplyResources(dos, "dos");
            dos.BackColor = SystemColors.ButtonFace;
            dos.Name = "dos";
            dos.UseVisualStyleBackColor = false;
            dos.Click += dos_Click;
            // 
            // ocho
            // 
            resources.ApplyResources(ocho, "ocho");
            ocho.BackColor = SystemColors.ButtonFace;
            ocho.Name = "ocho";
            ocho.UseVisualStyleBackColor = false;
            ocho.Click += ocho_Click;
            // 
            // tres
            // 
            resources.ApplyResources(tres, "tres");
            tres.BackColor = SystemColors.ButtonFace;
            tres.Name = "tres";
            tres.UseVisualStyleBackColor = false;
            tres.Click += tres_Click;
            // 
            // seis
            // 
            resources.ApplyResources(seis, "seis");
            seis.BackColor = SystemColors.ButtonFace;
            seis.Name = "seis";
            seis.UseVisualStyleBackColor = false;
            seis.Click += seis_Click;
            // 
            // borrarButton
            // 
            resources.ApplyResources(borrarButton, "borrarButton");
            borrarButton.BackColor = SystemColors.ButtonFace;
            borrarButton.Name = "borrarButton";
            borrarButton.UseVisualStyleBackColor = false;
            borrarButton.Click += borrarButton_Click;
            // 
            // clearButton
            // 
            resources.ApplyResources(clearButton, "clearButton");
            clearButton.BackColor = SystemColors.ButtonFace;
            clearButton.Name = "clearButton";
            clearButton.UseVisualStyleBackColor = false;
            clearButton.Click += clearButton_Click;
            // 
            // igual
            // 
            resources.ApplyResources(igual, "igual");
            igual.BackColor = SystemColors.ButtonFace;
            igual.Name = "igual";
            igual.UseVisualStyleBackColor = false;
            igual.Click += igual_Click;
            // 
            // puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas
            // 
            resources.ApplyResources(puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas, "puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas");
            puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas.BackColor = SystemColors.ButtonFace;
            puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas.Name = "puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas";
            puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas.UseVisualStyleBackColor = false;
            puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas.Click += puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas_Click;
            // 
            // cero
            // 
            resources.ApplyResources(cero, "cero");
            cero.BackColor = SystemColors.ButtonFace;
            cero.Name = "cero";
            cero.UseVisualStyleBackColor = false;
            cero.Click += button20_Click;
            // 
            // multiplicarButton
            // 
            resources.ApplyResources(multiplicarButton, "multiplicarButton");
            multiplicarButton.BackColor = SystemColors.ButtonFace;
            multiplicarButton.Name = "multiplicarButton";
            multiplicarButton.UseVisualStyleBackColor = false;
            multiplicarButton.Click += multiplicarButton_Click;
            // 
            // dividirButton
            // 
            resources.ApplyResources(dividirButton, "dividirButton");
            dividirButton.BackColor = SystemColors.ButtonFace;
            dividirButton.Name = "dividirButton";
            dividirButton.UseVisualStyleBackColor = false;
            dividirButton.Click += dividirButton_Click;
            // 
            // sumarButton
            // 
            resources.ApplyResources(sumarButton, "sumarButton");
            sumarButton.BackColor = SystemColors.ButtonFace;
            sumarButton.Name = "sumarButton";
            sumarButton.UseVisualStyleBackColor = false;
            sumarButton.Click += sumarButton_Click;
            // 
            // campoDeTextoDeLaCalculadoraPaCalcularLosCalculos
            // 
            resources.ApplyResources(campoDeTextoDeLaCalculadoraPaCalcularLosCalculos, "campoDeTextoDeLaCalculadoraPaCalcularLosCalculos");
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Name = "campoDeTextoDeLaCalculadoraPaCalcularLosCalculos";
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.ReadOnly = true;
            // 
            // nueve
            // 
            resources.ApplyResources(nueve, "nueve");
            nueve.BackColor = SystemColors.ButtonFace;
            nueve.Name = "nueve";
            nueve.UseVisualStyleBackColor = false;
            nueve.Click += nueve_Click;
            // 
            // cinco
            // 
            resources.ApplyResources(cinco, "cinco");
            cinco.BackColor = SystemColors.ButtonFace;
            cinco.Name = "cinco";
            cinco.UseVisualStyleBackColor = false;
            cinco.Click += button1_Click;
            // 
            // restarButton
            // 
            resources.ApplyResources(restarButton, "restarButton");
            restarButton.BackColor = SystemColors.ButtonFace;
            restarButton.Name = "restarButton";
            restarButton.UseVisualStyleBackColor = false;
            restarButton.Click += restarButton_Click;
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            Controls.Add(restarButton);
            Controls.Add(cinco);
            Controls.Add(nueve);
            Controls.Add(campoDeTextoDeLaCalculadoraPaCalcularLosCalculos);
            Controls.Add(multiplicarButton);
            Controls.Add(dividirButton);
            Controls.Add(sumarButton);
            Controls.Add(igual);
            Controls.Add(puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas);
            Controls.Add(cero);
            Controls.Add(borrarButton);
            Controls.Add(clearButton);
            Controls.Add(tres);
            Controls.Add(seis);
            Controls.Add(dos);
            Controls.Add(ocho);
            Controls.Add(uno);
            Controls.Add(cuatro);
            Controls.Add(siete);
            Cursor = Cursors.Hand;
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Name = "Form1";
            Load += Calculadora_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button siete;
        private Button uno;
        private Button cuatro;
        private Button dos;
        private Button ocho;
        private Button tres;
        private Button seis;
        private Button borrarButton;
        private Button clearButton;
        private Button igual;
        private Button puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas;
        private Button cero;
        private Button multiplicarButton;
        private Button dividirButton;
        private Button sumarButton;
        private TextBox campoDeTextoDeLaCalculadoraPaCalcularLosCalculos;
        private Button nueve;
        private Button cinco;
        private Button restarButton;
    }
}