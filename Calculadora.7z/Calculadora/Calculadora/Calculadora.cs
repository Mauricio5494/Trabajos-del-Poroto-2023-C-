namespace Calculadora
{
    public partial class Form1 : Form
    {

        double primero, segundo;
        String operador;
#pragma warning disable CS8618 // Un campo que no acepta valores NULL debe contener un valor distinto de NULL al salir del constructor. Considere la posibilidad de declararlo como que admite un valor NULL.
        public Form1()
#pragma warning restore CS8618 // Un campo que no acepta valores NULL debe contener un valor distinto de NULL al salir del constructor. Considere la posibilidad de declararlo como que admite un valor NULL.
        //Me ten�a enfermo esa advertencia de mrd.
        {
            InitializeComponent();
        }
        //goofy aah Calculadora.
        bool comaIsAlreadyExists = false;

        readonly Clases.ClassSuma obj = new();
        readonly Clases.ClassResta obj2 = new();
        readonly Clases.ClassMultiplicacion obj3 = new();
        readonly Clases.ClassDivision obj4 = new();

        private void button20_Click(object sender, EventArgs e)
        {
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text += "0";
        }

        private void puntoOseaEsLiteralmenteUnPuntoQueTeEsperabasEsUnPuntoYPuntoSeAcaboDeEstoNoSeHablaMas_Click(object sender, EventArgs e)
        {

            if (!comaIsAlreadyExists)
            {
                campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text += ".";
                comaIsAlreadyExists = true;
            }
            else
            {
                campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text += null;

            }

        }

        private void uno_Click(object sender, EventArgs e)
        {
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text + "1";
        }

        private void dos_Click(object sender, EventArgs e)
        {
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text + "2";
        }

        private void tres_Click(object sender, EventArgs e)
        {
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text + "3";
        }

        private void cuatro_Click(object sender, EventArgs e)
        {
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text + "4";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text + "5";
        }

        private void seis_Click(object sender, EventArgs e)
        {
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text + "6";
        }

        private void siete_Click(object sender, EventArgs e)
        {
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text + "7";
        }

        private void ocho_Click(object sender, EventArgs e)
        {
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text + "8";
        }

        private void nueve_Click(object sender, EventArgs e)
        {
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text + "9";
        }

        private void multiplicarButton_Click(object sender, EventArgs e)
        {
            if (campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text != "")
            {
                operador = "*";
                primero = double.Parse(campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text);
                campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Clear();
                comaIsAlreadyExists = false;
            }
            else
            {
                MessageBox.Show("Ingresa un numero antes de meter un operador aritm�tico");
            }

        }

        private void dividirButton_Click(object sender, EventArgs e)
        {
            if (campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text != "")
            {
                operador = "/";
                primero = double.Parse(campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text);
                campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Clear();
                comaIsAlreadyExists = false;
            }
            else
            {
                MessageBox.Show("Ingrese un n�mero antes de meter un operador aritm�tico");
            }

        }

        private void sumarButton_Click(object sender, EventArgs e)
        {
            if (campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text != "")
            {
                operador = "+";
                primero = double.Parse(campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text);
                campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Clear();
                comaIsAlreadyExists = false;
            }
            else
            {
                MessageBox.Show("Ingrese un n�mero antes de meter un operador aritm�tico");
            }

        }

        private void restarButton_Click(object sender, EventArgs e)
        {
            if (campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text != "")
            {
                operador = "-";
                primero = double.Parse(campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text);
                campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Clear();
                comaIsAlreadyExists = false;
            }
            else
            {
                MessageBox.Show("Ingrese un n�mero antes de meter un operador aritm�tico");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Clear();
            comaIsAlreadyExists = false;
        }

        private void borrarButton_Click(object sender, EventArgs e)
        {
            if (campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text.Length > 0)
            {
                if (campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text.EndsWith(""))
                {
                    comaIsAlreadyExists = false;

                }
                campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text.Remove
                    (campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text.Length - 1);
            }
        }

        private void igual_Click(object sender, EventArgs e)
        {
            segundo = double.Parse(campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text);

            double sumaIgual;
            double restaIgual;
            double divisionIugal;
            double multipIgual;

            switch (operador)
            {
                case "+":
                    sumaIgual = sumaIgual = obj.Sumar((primero), (segundo));
                    campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = sumaIgual.ToString();
                    break;
                case "-":
                    restaIgual = restaIgual = obj2.Restar((primero), (segundo));
                    campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = restaIgual.ToString();
                    break;
                case "*":
                    multipIgual = multipIgual = obj3.Multiplicar((primero), (segundo));
                    campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = multipIgual.ToString();
                    break;
                case "/":
                    divisionIugal = divisionIugal = obj4.Dividir((primero), (segundo));
                    campoDeTextoDeLaCalculadoraPaCalcularLosCalculos.Text = divisionIugal.ToString();
                    break;
            }

        }

        private void Calculadora_Load(object sender, EventArgs e)
        {
            //this.SetDesktopLocation(x: 683, y: 364);
            //this.FormBorderStyle = FormBorderStyle.FixedDialog;
        }
    }
}