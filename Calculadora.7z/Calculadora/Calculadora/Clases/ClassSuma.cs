﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora.Clases
{
    internal class ClassSuma
    {
        public double Sumar(double n1, double n2)
        {
            double S;
            S = n1 + n2;
            return S;
        }
    }
}
